﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CLouroA02.Entities
{
    [Bind("PartyId", "Description", "EventDate", "Location")]
    public class Party
    {
        public int PartyId { get; set; }

        [Required] public string Description { get; set; }

        [Required] public DateTime EventDate { get; set; }

        public string? Location { get; set; }

        public List<Invitation>? Invitations { get; set; }

        public int InvitationsCount => Invitations?.Count ?? 0;
    }
}