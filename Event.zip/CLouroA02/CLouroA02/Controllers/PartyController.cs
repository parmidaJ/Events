﻿using CLouroA02.Entities;
using CLouroA02.Models;
using CLouroA02.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CLouroA02.Controllers
{
    public class PartyController : Controller
    {
        private readonly PartyDbContext _partyDbContext;
        private readonly IEmailService _emailService;

        public PartyController(PartyDbContext partyDbContext, IEmailService emailService)
        {
            _partyDbContext = partyDbContext;
            _emailService = emailService;
        }

        public IActionResult Index()
        {
            var parties = _partyDbContext.Parties
                .Include(p => p.Invitations)
                .ToList();
            return View(parties);
        }

        [HttpGet]
        public IActionResult Add()
        {
            Party party = new Party()
            {
                EventDate = DateTime.Now,
            };
            return View(party);
        }

        [HttpPost]
        public IActionResult Add(Party partyModel)
        {
            if (ModelState.IsValid)
            {
                _partyDbContext.Parties.Add(partyModel);
                _partyDbContext.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(partyModel);
        }

        [HttpGet]
        public IActionResult Edit(int partyId)
        {
            var party = _partyDbContext.Parties.Find(partyId);
            return View(party);
        }

        [HttpPost]
        public IActionResult Edit(Party partyModel)
        {
            if (ModelState.IsValid)
            {
                _partyDbContext.Parties.Update(partyModel);
                _partyDbContext.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(partyModel);
        }

        [HttpGet]
        public IActionResult Manage(int partyId)
        {
            var party = _partyDbContext.Parties
                .Include(p => p.Invitations)
                .Single(p => p.PartyId == partyId);

            ManagePartyModel managePartyModel = new ManagePartyModel()
            {
                Party = party,
                Invitation = new Invitation()
            };

            return View(managePartyModel);
        }

        [HttpPost]
        public IActionResult Manage([Bind("GuestName", "GuestEmail", "PartyId")] Invitation invitation)
        {
            if (ModelState.IsValid)
            {
                invitation.Status = InvitationStatus.InviteNotSent;
                _partyDbContext.Invitation.Add(invitation);
                _partyDbContext.SaveChanges();

                return RedirectToAction("Manage", new RouteValueDictionary { { "partyId", invitation.PartyId } });
            }

            var party = _partyDbContext.Parties
                .Include(p => p.Invitations)
                .Single(p => p.PartyId == invitation.PartyId);

            ManagePartyModel managePartyModel = new ManagePartyModel()
            {
                Party = party,
                Invitation = invitation
            };

            return View(managePartyModel);
        }

        [HttpPost]
        public RedirectToActionResult SendInvitations(int partyId)
        {
            var invitations = _partyDbContext.Invitation
                .Include(i => i.Party)
                .Where(i => i.PartyId == partyId)
                .Where(i => i.Status == InvitationStatus.InviteNotSent)
                .ToList();

            _emailService.SendInvitationEmails(invitations);

            invitations.ForEach(i => i.Status = InvitationStatus.InviteSent);
            _partyDbContext.Invitation.UpdateRange(invitations);
            _partyDbContext.SaveChanges();

            return RedirectToAction("Manage", new RouteValueDictionary { { "partyId", partyId } });
        }
    }
}