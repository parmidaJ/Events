﻿using CLouroA02.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CLouroA02.Controllers;

public class InvitationController : Controller
{
    private PartyDbContext _partyDbContext;

    public InvitationController(PartyDbContext partyDbContext)
    {
        _partyDbContext = partyDbContext;
    }

    [HttpGet]
    public IActionResult GuestResponse(int invitationId)
    {
        Invitation invitation = _partyDbContext.Invitation
            .Include(i => i.Party)
            .Single(i => i.InvitationId == invitationId);

        return View(invitation);
    }

    [HttpPost]
    public IActionResult GuestResponse(Invitation invitation)
    {
        if (!ModelState.IsValid)
        {
            return View(invitation);
        }

        _partyDbContext.Invitation.Update(invitation);
        _partyDbContext.SaveChanges();

        return RedirectToAction("ThankYou", new RouteValueDictionary { { "status", invitation.Status } });
    }

    public IActionResult ThankYou(InvitationStatus status)
    {
        return View(status);
    }
}