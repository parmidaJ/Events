﻿using System.Net;
using System.Net.Mail;
using CLouroA02.Entities;

namespace CLouroA02.Services;

public class EmailService : IEmailService
{
    private const string FromAddress = "caioslouro@gmail.com";
    private const string EmailPassword = "nruqwzzrwnqgcsdo";

    public void SendInvitationEmails(IEnumerable<Invitation> invitations)
    {
        foreach (var invitation in invitations)
        {
             var smtpClient = new SmtpClient("smtp.gmail.com")
            {
                Port = 587,
                Credentials = new NetworkCredential(FromAddress, EmailPassword),
                EnableSsl = true
            };
            
            var mailMessage = new MailMessage()
            {
                From = new MailAddress(FromAddress),
                Subject = $"You have been invited to the \"{invitation.Party.Description}\"",
                Body = $"<h1>Hello {invitation.GuestName}.</h1>" +
                       $"<p>You have been invited to the \"{invitation.Party.Description}\" at " +
                       $"{invitation.Party.Location} on {invitation.Party.EventDate.ToShortDateString()}!</p>" +
                       "<p>We would be thrilled to have you so please <a " +
                       $"href=\"https://localhost:7271/Invitation/GuestResponse?invitationId={invitation.InvitationId}\"" +
                       ">let us know</a> " +
                       "if you can as soon as possible!</p>" +
                       "<p>Sincerely,</p><p>The Party Manager App</p>",
                IsBodyHtml = true
            };

            mailMessage.To.Add(invitation.GuestEmail);

            smtpClient.SendAsync(mailMessage, null);
        }
    }
}