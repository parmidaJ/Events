﻿using CLouroA02.Entities;

namespace CLouroA02.Services;

public interface IEmailService
{
    public void SendInvitationEmails(IEnumerable<Invitation> invitations);
}